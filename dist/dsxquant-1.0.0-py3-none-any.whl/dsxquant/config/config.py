
# 市场代码
class MARKET:
    SH=0
    SZ=1
    BJ=2
    HK=3
    US=4

class FQ:
    DEFAULT=''
    QFQ="qfq"
    HFQ="hfq"

# socket 链接超时
CONNECT_TIMEOUT = 30
# 头部长度
RSP_HEADER_LEN = 0x4