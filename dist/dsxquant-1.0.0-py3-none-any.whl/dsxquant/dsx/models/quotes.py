
class QuoteModel(object):
    name:str = ""
    symbol:str = ""