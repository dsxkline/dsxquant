import dsxquant

dsxquant.restfulapi.run(verify=False)